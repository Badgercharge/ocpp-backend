import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_BASE || '';

export default function WeatherSettings({ stationUid }){
  const [settings, setSettings] = useState({ weather_mode_enabled:false, weather_location:'Berlin,DE', min_power_kw:2, max_power_kw:11 });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(()=>{
    async function load(){
      try{
        const res = await axios.get(`${API_BASE}/v1/stations/${stationUid}`);
        setSettings(res.data);
      }catch(e){
      }
    }
    load();
  }, [stationUid]);

  const save = async ()=>{
    setLoading(true);
    try{
      await axios.post(`${API_BASE}/v1/stations/${stationUid}/weather-settings`, settings);
      setMessage('Gespeichert');
    }catch(e){
      setMessage('Fehler beim Speichern');
    }
    setLoading(false);
  }

  return (
    <div style={{border:'1px solid #ccc', padding:20, maxWidth:600}}>
      <h3>Wetterabhängiges Laden</h3>
      <label><input type='checkbox' checked={settings.weather_mode_enabled} onChange={e=>setSettings({...settings, weather_mode_enabled: e.target.checked})} /> Aktiv</label>
      <div style={{marginTop:10}}>
        <label>Ort (z.B. Berlin,DE)</label><br/>
        <input value={settings.weather_location} onChange={e=>setSettings({...settings, weather_location: e.target.value})} style={{width:'100%'}} />
      </div>
      <div style={{marginTop:10}}>
        <label>Min Leistung (kW)</label><br/>
        <input type='number' value={settings.min_power_kw} onChange={e=>setSettings({...settings, min_power_kw: parseFloat(e.target.value)})} />
      </div>
      <div style={{marginTop:10}}>
        <label>Max Leistung (kW)</label><br/>
        <input type='number' value={settings.max_power_kw} onChange={e=>setSettings({...settings, max_power_kw: parseFloat(e.target.value)})} />
      </div>
      <div style={{marginTop:10}}>
        <button onClick={save} disabled={loading}>Speichern</button>
      </div>
      <div style={{marginTop:10, color:'green'}}>{message}</div>
    </div>
  );
}

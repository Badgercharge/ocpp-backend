import React from 'react';
import WeatherSettings from './components/WeatherSettings';

function App(){
  return (
    <div style={{padding:20}}>
      <h1>OCPP Admin Portal - Wetter-Modus (Demo)</h1>
      <WeatherSettings stationUid={'DEMO1'} />
    </div>
  );
}

export default App;

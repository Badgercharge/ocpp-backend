# Simulated charger client (very small test harness)
import asyncio, websockets, json, argparse, random, time, sys

async def run(uri, cp_id):
    async with websockets.connect(uri) as ws:
        boot = {'action':'BootNotification','payload':{'chargePointVendor':'SIMV','chargePointModel':'SIM1'}}
        await ws.send(json.dumps(boot))
        print('Sent BootNotification')
        resp = await ws.recv()
        print('Received:', resp)

        tx_id = 'sim-tx-' + str(int(time.time()))
        start = {'action':'StartTransaction','transactionId':tx_id,'connectorId':1,'meterStart':0}
        await ws.send(json.dumps(start))
        print('Sent StartTransaction', tx_id)
        resp = await ws.recv()
        print('Received:', resp)

        for i in range(1,6):
            mv = {'action':'MeterValues','payload':{'transactionId':tx_id,'timestamp': int(time.time()),'meterWh': i*2000}}
            await ws.send(json.dumps(mv))
            print('Sent MeterValues', mv['payload']['meterWh'])
            await asyncio.sleep(1)

        stop = {'action':'StopTransaction','transactionId':tx_id,'meterStop':10000}
        await ws.send(json.dumps(stop))
        print('Sent StopTransaction')
        resp = await ws.recv()
        print('Received:', resp)

        await asyncio.sleep(1)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', default='ws://localhost:8000/ocpp/CP_SIM_1')
    parser.add_argument('--cp', default='CP_SIM_1')
    args = parser.parse_args()
    try:
        asyncio.run(run(args.url, args.cp))
    except Exception as e:
        print('Error:', e)
        sys.exit(1)

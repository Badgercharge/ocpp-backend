from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import sqlite3
import os

router = APIRouter()

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///data/data.db')

class WeatherSettings(BaseModel):
    weather_mode_enabled: bool
    weather_location: str
    min_power_kw: float
    max_power_kw: float

def db_path_from_url(url: str):
    if url.startswith('sqlite:///'):
        return url.replace('sqlite:///', '')
    return None

@router.post('/v1/stations/{station_uid}/weather-settings')
async def set_weather_settings(station_uid: str, settings: WeatherSettings):
    dbpath = db_path_from_url(DATABASE_URL)
    if not dbpath:
        raise HTTPException(status_code=500, detail='Unsupported DB in scaffold')
    conn = sqlite3.connect(dbpath)
    cur = conn.cursor()
    cur.execute('SELECT id FROM stations WHERE station_uid = ?', (station_uid,))
    row = cur.fetchone()
    if not row:
        cur.execute('INSERT INTO stations (station_uid, weather_mode_enabled, weather_location, min_power_kw, max_power_kw) VALUES (?, ?, ?, ?, ?)', (station_uid, 0, settings.weather_location, settings.min_power_kw, settings.max_power_kw))
        conn.commit()
        cur.execute('SELECT id FROM stations WHERE station_uid = ?', (station_uid,))
        row = cur.fetchone()
    cur.execute('UPDATE stations SET weather_mode_enabled=?, weather_location=?, min_power_kw=?, max_power_kw=? WHERE station_uid=?', (1 if settings.weather_mode_enabled else 0, settings.weather_location, settings.min_power_kw, settings.max_power_kw, station_uid))
    conn.commit()
    conn.close()
    return {'status': 'ok', 'station_uid': station_uid, 'weather_mode_enabled': settings.weather_mode_enabled}

@router.get('/v1/stations/{station_uid}')
async def get_station(station_uid: str):
    dbpath = db_path_from_url(DATABASE_URL)
    if not dbpath:
        raise HTTPException(status_code=500, detail='Unsupported DB in scaffold')
    conn = sqlite3.connect(dbpath)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute('SELECT station_uid, weather_mode_enabled, weather_location, min_power_kw, max_power_kw FROM stations WHERE station_uid = ?', (station_uid,))
    row = cur.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail='Station not found')
    return {'station_uid': row['station_uid'], 'weather_mode_enabled': bool(row['weather_mode_enabled']), 'weather_location': row['weather_location'], 'min_power_kw': row['min_power_kw'], 'max_power_kw': row['max_power_kw']}

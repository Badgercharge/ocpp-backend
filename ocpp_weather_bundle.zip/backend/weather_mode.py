import os
import asyncio
import httpx
from decimal import Decimal
import logging
import sqlite3

from .ocpp_gateway import gateway

OPENWEATHER_KEY = os.getenv('OPENWEATHER_API_KEY')
CHECK_INTERVAL = int(os.getenv('WEATHER_CHECK_INTERVAL_MINUTES', '10'))
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///data/data.db')

def fetch_weather_enabled_stations():
    try:
        if DATABASE_URL.startswith('sqlite:///'):
            db_path = DATABASE_URL.replace('sqlite:///', '')
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT id, station_uid, weather_location, min_power_kw, max_power_kw FROM stations WHERE weather_mode_enabled = 1")
            rows = cur.fetchall()
            conn.close()
            return rows
        else:
            return []
    except Exception as e:
        logging.error('DB error in fetch_weather_enabled_stations: %s', e)
        return []

async def get_weather_clear(location: str) -> bool:
    if not OPENWEATHER_KEY or not location:
        return False
    url = 'https://api.openweathermap.org/data/2.5/weather'
    params = {'q': location, 'appid': OPENWEATHER_KEY, 'units': 'metric'}
    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(url, params=params, timeout=10)
            if r.status_code != 200:
                logging.warning('OpenWeather returned status %s for location %s', r.status_code, location)
                return False
            data = r.json()
            weather = data.get('weather', [])
            if not weather:
                return False
            main = weather[0].get('main', '')
            return main == 'Clear'
    except Exception as e:
        logging.error('Error fetching weather: %s', e)
        return False

async def weather_mode_loop():
    logging.info('Starting weather_mode_loop, interval %d minutes', CHECK_INTERVAL)
    while True:
        try:
            rows = fetch_weather_enabled_stations()
            for row in rows:
                station_id = row['station_uid'] or row['id']
                location = row['weather_location'] or ''
                try:
                    min_pw = Decimal(row['min_power_kw'] or 2)
                    max_pw = Decimal(row['max_power_kw'] or 11)
                except Exception:
                    min_pw = Decimal('2.0')
                    max_pw = Decimal('11.0')
                is_clear = await get_weather_clear(location)
                target = float(max_pw) if is_clear else float(min_pw)
                logging.info('Station %s weather %s -> target power %s kW', station_id, 'Clear' if is_clear else 'Not Clear', target)
                await gateway.set_max_power(station_id, target)
        except Exception as e:
            logging.error('Error in weather_mode_loop main: %s', e)
        await asyncio.sleep(CHECK_INTERVAL * 60)

import asyncio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .ocpp_gateway import gateway  # shared gateway instance
from . import settings_api  # mounts router
from .weather_mode import weather_mode_loop

app = FastAPI(title='OCPP Backend Platform - Weather Mode')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*']
)

app.include_router(settings_api.router)

@app.get('/healthz')
async def health():
    return {'status': 'ok'}

@app.on_event('startup')
async def startup_event():
    # Start weather mode loop as background task
    asyncio.create_task(weather_mode_loop())

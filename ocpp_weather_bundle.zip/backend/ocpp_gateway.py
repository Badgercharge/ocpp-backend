import asyncio, json, logging
from typing import Dict
from fastapi import WebSocket

class ChargePointSession:
    def __init__(self, websocket: WebSocket, cp_id: str):
        self.websocket = websocket
        self.cp_id = cp_id
        self.last_seen = None
        self.state = {}

class OCPPGateway:
    def __init__(self):
        self._sessions: Dict[str, ChargePointSession] = {}
        self._transactions = {}  # transaction_id -> (cp_id, connector_id)

    async def register_charge_point(self, websocket: WebSocket, cp_id: str):
        await websocket.accept()
        self._sessions[cp_id] = ChargePointSession(websocket, cp_id)
        logging.info(f'Charge point connected: {cp_id}')

    async def disconnect_charge_point(self, cp_id: str):
        self._sessions.pop(cp_id, None)
        logging.info(f'Charge point disconnected: {cp_id}')

    async def handle_message(self, cp_id: str, text: str):
        try:
            msg = json.loads(text)
        except Exception:
            logging.warning('Malformed message from %s', cp_id)
            return
        action = msg.get('action')
        if action == 'BootNotification':
            await self._handle_bootnotification(cp_id, msg)
        elif action == 'StartTransaction':
            await self._handle_start(cp_id, msg)
        elif action == 'StopTransaction':
            await self._handle_stop(cp_id, msg)
        else:
            logging.info('Unhandled action %s from %s', action, cp_id)

    async def _handle_bootnotification(self, cp_id: str, msg: dict):
        resp = {'status':'Accepted','currentTime':'2025-10-14T00:00:00Z','interval':300}
        await self._sessions[cp_id].websocket.send_text(json.dumps({'action':'BootNotification.conf','payload':resp}))

    async def _handle_start(self, cp_id: str, msg: dict):
        transaction_id = msg.get('transactionId') or 'tx-' + str(len(self._transactions)+1)
        connector_id = msg.get('connectorId')
        self._transactions[transaction_id] = (cp_id, connector_id)
        resp = {'status':'Accepted','transactionId': transaction_id}
        await self._sessions[cp_id].websocket.send_text(json.dumps({'action':'StartTransaction.conf','payload':resp}))

    async def _handle_stop(self, cp_id: str, msg: dict):
        transaction_id = msg.get('transactionId')
        resp = {'status':'Accepted','transactionId': transaction_id}
        await self._sessions[cp_id].websocket.send_text(json.dumps({'action':'StopTransaction.conf','payload':resp}))

    async def remote_stop_by_transaction(self, transaction_id: str) -> bool:
        mapping = self._transactions.get(transaction_id)
        if not mapping:
            return False
        cp_id, connector_id = mapping
        session = self._sessions.get(cp_id)
        if not session:
            return False
        cmd = {'action':'RemoteStopTransaction','payload':{'transactionId': transaction_id}}
        await session.websocket.send_text(json.dumps(cmd))
        return True

    async def set_max_power(self, station_id: str, power_kw: float):
        session = self._sessions.get(station_id)
        if not session:
            logging.info(f"Station {station_id} not connected; cannot set power.")
            return False
        try:
            voltage = 230.0
            current_a = int(round(power_kw * 1000.0 / voltage))
        except Exception:
            current_a = int(power_kw)
        cmd = {
            "action": "ChangeConfiguration",
            "payload": {
                "key": "MaxCurrent",
                "value": str(current_a)
            }
        }
        await session.websocket.send_text(json.dumps(cmd))
        logging.info(f"Sent ChangeConfiguration to {station_id}: MaxCurrent={current_a}A ({power_kw} kW)")
        return True

gateway = OCPPGateway()
